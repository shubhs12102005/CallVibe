import React from 'react';
import { ArrowUpRight, Mail, MapPin } from 'lucide-react';

export default function Footer({ onOpenBooking, onNavigate }) {
  return (
    <footer style={{ backgroundColor: '#F8FAFC', borderTop: '1px solid #E2E8F0', paddingTop: '80px', paddingBottom: '40px' }}>
      <div className="container">
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1.4fr 0.8fr 0.8fr 1.2fr',
            gap: '48px',
            marginBottom: '60px',
          }}
          className="footer-grid"
        >
          {/* Col 1: Brand & Contact */}
          <div>
            <div 
              onClick={() => onNavigate('home')} 
              style={{ display: 'inline-flex', alignItems: 'center', marginBottom: '16px', cursor: 'pointer' }}
              title="CallVibe Home"
            >
              <img
                src="/images/silgate-logo.jpeg"
                alt="Silgate Logo"
                style={{ height: '32px', width: 'auto' }}
              />
            </div>

            <p style={{ fontSize: '15px', color: '#64748B', marginBottom: '24px' }}>
              Ready to start your project? Let's connect today.
            </p>

            <div
              style={{
                borderLeft: '2px solid #CBD5E1',
                paddingLeft: '16px',
                display: 'flex',
                flexDirection: 'column',
                gap: '10px',
                marginBottom: '24px',
              }}
            >
              <div style={{ fontSize: '14px', color: '#334155' }}>
                Email: <a href="mailto:manoj@silgatehiring.com" style={{ color: '#0F172A', fontWeight: '700', textDecoration: 'none' }}>manoj@silgatehiring.com</a>
              </div>
              <div style={{ fontSize: '14px', color: '#334155' }}>
                Phone: <a href="tel:+918108810916" style={{ color: '#0F172A', fontWeight: '700', textDecoration: 'none' }}>+91 81088 10916</a>
              </div>
              <div style={{ fontSize: '13px', color: '#64748B', lineHeight: 1.5 }}>
                Road No 8, SG Barve RD, Wagle Estate, Padwal Nagar<br />
                Thane West, Maharashtra 400604
              </div>
            </div>

            <button
              onClick={onOpenBooking}
              className="btn btn-outline"
              style={{
                fontSize: '13px',
                padding: '8px 18px',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '6px',
                color: '#2264F6',
                borderColor: '#BFDBFE',
                backgroundColor: '#EFF6FF',
              }}
            >
              <span>Schedule a Consultation</span>
              <ArrowUpRight size={14} />
            </button>
          </div>

          {/* Col 2: Product & Platform */}
          <div>
            <div style={{ fontSize: '13px', fontWeight: '700', color: '#2264F6', letterSpacing: '0.04em', textTransform: 'uppercase', marginBottom: '16px' }}>
              Platform
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <button
                onClick={() => onNavigate('features')}
                style={{ textAlign: 'left', fontSize: '15px', fontWeight: '600', color: '#1E293B', transition: 'color 0.2s' }}
                onMouseEnter={(e) => (e.target.style.color = '#2264F6')}
                onMouseLeave={(e) => (e.target.style.color = '#1E293B')}
              >
                Features
              </button>
              <button
                onClick={() => onNavigate('integrations')}
                style={{ textAlign: 'left', fontSize: '15px', fontWeight: '600', color: '#1E293B', transition: 'color 0.2s' }}
                onMouseEnter={(e) => (e.target.style.color = '#2264F6')}
                onMouseLeave={(e) => (e.target.style.color = '#1E293B')}
              >
                Integrations
              </button>
              <button
                onClick={() => onNavigate('blog')}
                style={{ textAlign: 'left', fontSize: '15px', fontWeight: '600', color: '#1E293B', transition: 'color 0.2s' }}
                onMouseEnter={(e) => (e.target.style.color = '#2264F6')}
                onMouseLeave={(e) => (e.target.style.color = '#1E293B')}
              >
                Blog & Insights
              </button>
              <button
                onClick={() => onNavigate('about')}
                style={{ textAlign: 'left', fontSize: '15px', fontWeight: '600', color: '#1E293B', transition: 'color 0.2s' }}
                onMouseEnter={(e) => (e.target.style.color = '#2264F6')}
                onMouseLeave={(e) => (e.target.style.color = '#1E293B')}
              >
                About Us
              </button>
            </div>
          </div>

          {/* Col 3: Access & Company */}
          <div>
            <div style={{ fontSize: '13px', fontWeight: '700', color: '#2264F6', letterSpacing: '0.04em', textTransform: 'uppercase', marginBottom: '16px' }}>
              Account & Legal
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <button
                onClick={() => onNavigate('login')}
                style={{ textAlign: 'left', fontSize: '15px', fontWeight: '600', color: '#2264F6', transition: 'color 0.2s' }}
                onMouseEnter={(e) => (e.target.style.color = '#1D4ED8')}
                onMouseLeave={(e) => (e.target.style.color = '#2264F6')}
              >
                Sign In
              </button>
              <button
                onClick={() => onNavigate('signup')}
                style={{ textAlign: 'left', fontSize: '15px', fontWeight: '600', color: '#1E293B', transition: 'color 0.2s' }}
                onMouseEnter={(e) => (e.target.style.color = '#2264F6')}
                onMouseLeave={(e) => (e.target.style.color = '#1E293B')}
              >
                Start Free Trial
              </button>
              <button
                onClick={() => onNavigate('contact')}
                style={{ textAlign: 'left', fontSize: '15px', fontWeight: '600', color: '#1E293B', transition: 'color 0.2s' }}
                onMouseEnter={(e) => (e.target.style.color = '#2264F6')}
                onMouseLeave={(e) => (e.target.style.color = '#1E293B')}
              >
                Contact
              </button>
              <button
                onClick={() => onNavigate('reviews')}
                style={{ textAlign: 'left', fontSize: '15px', fontWeight: '600', color: '#1E293B', transition: 'color 0.2s' }}
                onMouseEnter={(e) => (e.target.style.color = '#2264F6')}
                onMouseLeave={(e) => (e.target.style.color = '#1E293B')}
              >
                Reviews
              </button>
              <button
                onClick={() => onNavigate('terms')}
                style={{ textAlign: 'left', fontSize: '15px', fontWeight: '600', color: '#1E293B', transition: 'color 0.2s' }}
                onMouseEnter={(e) => (e.target.style.color = '#2264F6')}
                onMouseLeave={(e) => (e.target.style.color = '#1E293B')}
              >
                Terms
              </button>
              <button
                onClick={() => onNavigate('privacy')}
                style={{ textAlign: 'left', fontSize: '15px', fontWeight: '600', color: '#1E293B', transition: 'color 0.2s' }}
                onMouseEnter={(e) => (e.target.style.color = '#2264F6')}
                onMouseLeave={(e) => (e.target.style.color = '#1E293B')}
              >
                Privacy
              </button>
            </div>
          </div>

          {/* Col 4: Socials & Certifications */}
          <div style={{ borderLeft: '1px solid #E2E8F0', paddingLeft: '32px' }} className="cert-col">
            <div style={{ marginBottom: '24px' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', color: '#2264F6', letterSpacing: '0.04em', textTransform: 'uppercase', marginBottom: '12px' }}>
                Follow Us
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    width: '38px',
                    height: '38px',
                    borderRadius: '50%',
                    backgroundColor: '#FFFFFF',
                    border: '1px solid #E2E8F0',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#0F172A',
                    transition: 'all 0.2s',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = '#2264F6';
                    e.currentTarget.style.borderColor = '#2264F6';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = '#0F172A';
                    e.currentTarget.style.borderColor = '#E2E8F0';
                  }}
                  aria-label="Facebook"
                >
                  <svg width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                  </svg>
                </a>
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    width: '38px',
                    height: '38px',
                    borderRadius: '50%',
                    backgroundColor: '#FFFFFF',
                    border: '1px solid #E2E8F0',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#0F172A',
                    transition: 'all 0.2s',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = '#2264F6';
                    e.currentTarget.style.borderColor = '#2264F6';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = '#0F172A';
                    e.currentTarget.style.borderColor = '#E2E8F0';
                  }}
                  aria-label="Instagram"
                >
                  <svg width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                  </svg>
                </a>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    width: '38px',
                    height: '38px',
                    borderRadius: '50%',
                    backgroundColor: '#FFFFFF',
                    border: '1px solid #E2E8F0',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#0F172A',
                    transition: 'all 0.2s',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = '#2264F6';
                    e.currentTarget.style.borderColor = '#2264F6';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = '#0F172A';
                    e.currentTarget.style.borderColor = '#E2E8F0';
                  }}
                  aria-label="LinkedIn"
                >
                  <svg width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
                  </svg>
                </a>
              </div>
            </div>

            <div>
              <div style={{ fontSize: '13px', fontWeight: '700', color: '#2264F6', letterSpacing: '0.04em', textTransform: 'uppercase', marginBottom: '14px' }}>
                Certifications
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '20px', flexWrap: 'wrap' }}>
                <img
                  src="/images/certified-corp-pixfort-logo-dark-1.webp"
                  alt="Certified B Corporation"
                  style={{ height: '48px', width: 'auto', objectFit: 'contain' }}
                />
                <img
                  src="/images/google-partner-pixfort-logo-1.webp"
                  alt="Google Partner"
                  style={{ height: '36px', width: 'auto', objectFit: 'contain' }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Copyright */}
        <div
          style={{
            textAlign: 'center',
            paddingTop: '32px',
            borderTop: '1px solid #E2E8F0',
            fontSize: '14px',
            color: '#64748B',
          }}
        >
          CallVibe © All rights reserved
        </div>
      </div>

      <style>{`
        @media (max-width: 991px) {
          .footer-grid {
            grid-template-columns: 1fr 1fr !important;
            gap: 32px !important;
          }
          .cert-col {
            border-left: none !important;
            padding-left: 0 !important;
            grid-column: span 2;
          }
        }
        @media (max-width: 600px) {
          .footer-grid {
            grid-template-columns: 1fr !important;
          }
          .cert-col {
            grid-column: span 1;
          }
        }
      `}</style>
    </footer>
  );
}
